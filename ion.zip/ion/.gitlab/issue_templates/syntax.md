feat: (description with motivation)

BREAKING CHANGE: (effect on current programs or datastructures?)

perf: impact

performance

usability

maintainability

code: input
```
shell code
```

expect: output
```
result
```

reason: (for what use case is this important)

context: (links, text and further literature)

behavior of bash/dash/zsh/fish/oil
