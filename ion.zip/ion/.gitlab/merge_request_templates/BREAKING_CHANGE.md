feat: description

closes issue: #RFC

closes issue: #bug

BREAKING CHANGE: (where how and what breaks)

test: unit?

test: integration in (default in `tests`, otherwise explain concise)

refactor: affects other tests or data structures?

docs: documented?

perf: performance impact?
