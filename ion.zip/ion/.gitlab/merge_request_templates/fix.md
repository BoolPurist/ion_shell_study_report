fix: description

closes issue: #bug

test: regression tested in (default in `tests`, otherwise explain concise)

refactor: (affects other tests or data structures?)

docs: (documented?)

perf: (performance impact?)
