#! ./testshell

#echo Caller is pid $$
./test20a.sh
echo Survived, should be. Exit code: $?

