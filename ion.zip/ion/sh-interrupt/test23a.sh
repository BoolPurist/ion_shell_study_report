#! ./testshell

#echo Second level is pid $$
./test23b.sh
echo Broken, exit code $?
