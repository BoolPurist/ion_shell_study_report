# Types-rs

A dynamically-typed datatype. Supports string, array, hashmap, binary-tree-map, 128 bit integer, decimal floating point and functions.
