# Scopes-rs

A generic data structure to organize variables in scopes
