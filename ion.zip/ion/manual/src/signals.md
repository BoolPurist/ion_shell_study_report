# Signal Handling

 - **SIGINT** (Ctrl + C): Interrupt the running program with a signal to terminate.
 - **SIGTSTP** (Ctrl + Z): Send the running job to the background, pausing it.